"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-22"
-------------------------------------------------------
"""
# Imports
from functions import hash_table
from Movie import Movie
values = []
movie1 = Movie("Dark City", 1998, None, None, None)
movie2 = Movie("Zulu", 1964, None, None, None)
movie3 = Movie("I Am Legend", 2007, None, None, None)
movie4 = Movie("Omega Man, The", 1971, None, None, None)
values.append(movie1)
values.append(movie2)
values.append(movie3)
values.append(movie4)
hash_table(7,values)



def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """