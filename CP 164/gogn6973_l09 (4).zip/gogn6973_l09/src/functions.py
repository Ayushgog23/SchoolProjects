"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-22"
-------------------------------------------------------
"""
# Imports
from List_array import List
from Movie import Movie

def hash_table(slots, values):
    """
    -------------------------------------------------------
    Print a hash table of a set of values. The format is:
    Hash     Slot Key
    -------- ---- --------------------
    1652346    3 Dark City, 1998
    848448    6 Zulu, 1964
    Do not create an actual Hash_Set.
    Use: hash_table(slots, values)
    -------------------------------------------------------
    Parameters:
       slots - the number of slots available (int > 0)
       values - the values to hash (list of ?)
    Returns:
       None
    -------------------------------------------------------
    """

    hashedvalues = List()
    for i in values:
        h = hash(i)
        hashedvalues.append(h)
        
    n = len(hashedvalues)
        
    print("Hash      Slot      Key")
    print("-" * 30)
    
    for i in range(0,n,1):
        hashedvalue = hashedvalues[i]
        slot = hashedvalue % slots
        value = values[i]
        key = f"{value.title}, {value.year}"
        print(f" {hashedvalue}  {slot:>5d} {key:<20s}")
    
       
    return None
    
    










def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """