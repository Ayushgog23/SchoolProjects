"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-22"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set

source = Hash_Set(5)
source.insert(5)
source.insert(11)
source.insert(7)
source.insert(12)
source.insert(3)
source.insert(9)
source._rehash()

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """