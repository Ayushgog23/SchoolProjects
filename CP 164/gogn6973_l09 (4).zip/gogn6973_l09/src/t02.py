"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-22"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set

source = Hash_Set(5)
source.insert(5)
source.insert(6)
source.remove(6)
print(source._table)




def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """