"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-15"
-------------------------------------------------------
"""
# Imports
from  functions import to_power

base = float(input("Enter a float: "))
power = int(input("Enter an exponent: "))
ans = to_power(base,power)
print(ans)

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """