"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-14"
-------------------------------------------------------
"""
# Imports
from functions import recurse

x = int(input("Enter an x value: "))
y = int(input("Enter a y value: "))
ans = recurse(x,y)
print(ans)

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """