"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-15"
-------------------------------------------------------
"""
# Imports
from functions import bag_to_set

bag = [4, 5, 3, 4, 5, 2, 2, 4]
new_set = bag_to_set(bag)
print(new_set)
 
def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """