"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-14"
-------------------------------------------------------
"""
# Imports
from functions import gcd

m = int(input("Enter a value: "))
n = int(input("Enter a value: "))
ans = gcd(m,n)
print(ans)

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """