"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-09"
-------------------------------------------------------
"""
from List_linked import List

source = List()
source.append(1)
source.append(2)
source.append(3)
target1,target2 = source.split_alt_r()
print(target1._front._value)
print(target2._front._value)

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """