"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-01"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
list = [55,44,33,22,11]
for i in list:
    source.append(i)
    
value = source[4]

source[4] = 100000
print(value)
print(source[4])
    
    
    


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """