"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-28"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
list = [11,22,33,44,55]
for i in list:
    source.append(i)
maxvalue = source.max()
minvalue = source.min()
n = source.count(55)
print(maxvalue)
print(minvalue)
print(n)

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """