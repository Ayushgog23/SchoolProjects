"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-01"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
list = [44,55,11,33,22]
for i in list:
    source.append(i)

value = source.peek()
removedvalue = source.remove(33)
print(value)
print(removedvalue)



def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """