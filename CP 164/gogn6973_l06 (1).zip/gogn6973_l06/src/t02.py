"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-28"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
list = [44,55,11,33,22]
for i in list:
    source.append(i)
    
previous, current, index = source._linear_search(99)
print(f"{previous}, {current}, {index}")

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """