"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-03-01"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
list = [11,22,33,44,55]
for i in list:
    source.append(i)

value = source.find(44)
n = source.index(44)
b = 55 in source

print(value)
print(n)
print(b)




def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """