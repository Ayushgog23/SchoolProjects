"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ayush Gogne
ID:      169026973
Email:   gogn6973@mylaurier.ca
__updated__ = "2023-02-24"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
list = [22,33,11,55,44]
for i in list:
    source.append(i)
    
source.prepend(1)
source.insert(4,1000)
print(source._front._value)
print(source._rear._value)
print(source)

def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """