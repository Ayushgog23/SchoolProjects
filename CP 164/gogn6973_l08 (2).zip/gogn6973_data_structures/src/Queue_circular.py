"""
-------------------------------------------------------
Circular array version of the Queue ADT.
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
Term:    Winter 2020
__updated__ = "2023-02-08"
-------------------------------------------------------
"""
# pylint: disable=protected-access

from copy import deepcopy
from pickle import FALSE, NONE, TRUE


class Queue:
    """
    -------------------------------------------------------
    Constants
    -------------------------------------------------------
    """
    # a default maximum size when one is not provided
    DEFAULT_CAPACITY = 10

    def __init__(self, capacity=DEFAULT_CAPACITY):
        """
        -------------------------------------------------------
        Initializes an empty queue. Data is stored in a fixed-size list.
        Use: target = Queue(capacity)
        Use: target = Queue()  # uses default capacity
        -------------------------------------------------------
        Parameters:
            capacity - maximum size of the queue (int > 0)
        Returns:
            a new Queue object (Queue)
        -------------------------------------------------------
        """
        assert capacity > 0, "Queue size must be > 0"

        self._capacity = capacity
        self._values = [None] * self._capacity
        self._front = None   # queue has no data
        self._rear = 0       # first available index for insertion
        self._count = 0      # number of data items

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the queue is empty.
        Use: empty = source.is_empty()
        -------------------------------------------------------
        Returns:
            True if the queue is empty, False otherwise.
        -------------------------------------------------------
        """
        empty = True
        for i in self._values:
            if i != None:
                empty = False
                
        return empty

    def is_full(self):
        """
        -------------------------------------------------------
        Determines if the queue is full.
        Use: full = source.is_full()
        -------------------------------------------------------
        Returns:
            True if the queue is full, False otherwise.
        -------------------------------------------------------
        """
        full = True
        for i in self._values:
            if i == None:
                full = False
        
        return full

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the length of the queue.
        Use: n = len(source)
        -------------------------------------------------------
        Returns:
            the number of values in the queue.
        -------------------------------------------------------
        """
        length = len(self._values)
        return length

    def __eq__(self, target):
        """
        ----------------
        Determines whether two Queues are equal.
        Values in self and target are compared and if all values are equal
        and in the same order, returns True, otherwise returns False.
        Use: equals = source == target
        ---------------
        Parameters:
            target - a queue (Queue)
        Returns:
            equals - True if source contains the same values
                as target in the same order, otherwise False. (boolean)
        ---------------
        """
        #[4, None, 1, 2, 3]   #[1, 2, 3, None, None] 
        
        equals = False
        
        if self.is_empty() or target.is_empty():
            if self.is_empty() and target.is_empty() and len(self._values) == len(target._values):
                equals = True
            
            
        elif self.is_full() or target.is_full():
            if self.is_full() and target.is_full() and len(self._values) == len(target._values):
                i = 0 
                while i < len(self._values) and self._values[i] == target._values[i]:
                    i += 1
                
                if i == len(self._values):
                    equals = True
            
                
        else:
            
            selflist = []
            targetlist = []
            if self._front == 0:
                j = 0
                while j != self._rear + 1:
                    selflist.append(self._values[j])
                    j += 1
                
                
            elif self._front > 0: 
                k = self._front
                while k < len(self._values) - self._front:
                    selflist.append(self._values[k])
                    k += 1
                    
                if self._values[0] != None:
                    z = 0
                    while self._values[z] != None:
                        selflist.append(self._values[z])
                        
            
            
            
            if target._front == 0:
                d = 0
                while d != target._rear + 1:
                    targetlist.append(target._values[d])
                    d += 1
                
                
            elif target._front != 0: 
                f = self._front
                while f < len(target._values) - target._front:
                    targetlist.append(target._values[f])
                    f += 1
                    
                if target._values[0] != None:
                    w = 0
                    while target._values[w] != None:
                        targetlist.append(self._values[w])
            
                
                
            if selflist == targetlist:
                equals = True
                
                    
                    
                
            
                
            
        
        
        
        return equals

    def insert(self, value):
        """
        -------------------------------------------------------
        Adds a copy of value to the rear of the queue.
        Use: source.insert( value )
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
         #[None,None,None, 6, 7,None]
         #   0   1     2   3   4    5
        full = self.is_full()
        assert full is False, "Cannot add to a full queue"
        
        
        valueinlist = False
        
        for i in self._values:
            if i != None:
                valueinlist = True
                
        if valueinlist == False:
            self._rear = 1
            self._front = 0
            
            rear = self._rear - 1
            
            self._values[rear] = value
            

        elif valueinlist == True and self._values[0] != None:
            j = 0
            self._rear = 1
            while self._values[j] != None:
                j += 1
                self._rear += 1
            
            if self._values[self._capacity - 1] != None:
                while self._values[j] == None:
                    j += 1
                
                self._front = j
                
                
            rear = self._rear - 1
           
            self._values[rear] = value
        elif valueinlist == True and self._values[0] == None:
            k = 0
            while self._values[k] == None:
                k += 1
                self._rear += 1
            
            self._front = k
            
            if self._values[self._capacity - 1] == None: 
                while self._values[k] != None:
                    k += 1
                    self._rear += 1
            elif self._values[self._capacity - 1] != None:
                z = 0
                while self._values[z] != None:
                    z += 1
                    
                self._rear = z
                
            rear = self._rear - 1
            self._values[rear] = value

        
        
        
        self._count += 1
        
        return None

    def remove(self):
        """
        -------------------------------------------------------
        Removes and returns value from the queue.
        Use: v = source.remove()
        -------------------------------------------------------
        Returns:
            value - the value at the front of the queue - the value is
                removed from the queue (?)
        -------------------------------------------------------
        """
                # [None,None,None, None, 6, None]
                #   0    1    2      3   4    5
        valueinlist = False
        for i in self._values:
            if i != None:
                valueinlist = True
                
        if valueinlist == False:
            self._front = None
        elif valueinlist == True:
            j = 0
            self._front = 0
            while self._values[j] == None:
                j += 1
                self._front += 1
        
        assert self._front is not None, "Cannot remove from an empty queue"
        
        value = self._values[self._front]
        self._values[self._front] = None
        self._front += 1
        
        
        return value

    def peek(self):
        """
        -------------------------------------------------------
        Peeks at the front of queue.
        Use: v = source.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the front of the queue -
                the value is not removed from the queue (?)
        -------------------------------------------------------
        """
        list = []
        for i in self._values:
            if i != None:
                list.append(i)
                
        self._count = len(list)
        
        valueinlist = False
        for i in self._values:
            if i != None:
                valueinlist = True
                
        if valueinlist == False:
            self._front = None
        elif valueinlist == True:
            self._front = 0
            j = 0
            while self._values[j] == None:
                j += 1
                self._front += 1
        
        assert self._count > 0, "Cannot peek at an empty queue"

        value = self._values[self._front]
        
        return value

    def __iter__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the queue
        from front to rear.
        Use: for v in cq:
        -------------------------------------------------------
        Returns:
            value - the next value in the queue (?)
        -------------------------------------------------------
        """
        if self._front is not None:
            # queue is not empty
            j = self._front
            i = 0

            while i < self._count:
                yield self._values[j]
                i += 1
                j = (j + 1) % self._capacity
